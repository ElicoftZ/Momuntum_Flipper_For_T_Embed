Drop firmware images (.bin) for the Dual Boot app in this folder.
Dual Boot lists every valid .bin here and installs it into free flash.
Invalid, truncated or wrong-device files are ignored, not installed.
