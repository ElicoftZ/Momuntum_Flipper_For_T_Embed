// hello_tembed.js -- smoke test for the JS runner on the T-Embed CC1101.
//
// Exercises console output, device info, notifications and SD storage, so a
// pass means the runner, its module system and the card are all working.
//
// Written in mJS's subset on purpose: no arrow functions, no template strings,
// no const. It therefore runs on the engine shipping today and will keep
// running unchanged once QuickJS is added, since QuickJS is a superset.

print("=== T-Embed JS smoke test ===");

// ---------------------------------------------------------------- console --
console.log("console.log works");
console.warn("console.warn works");
console.error("console.error works");

// ----------------------------------------------------------- device info --
let flipper = require("flipper");
print("Model:   " + flipper.getModel());
print("Name:    " + flipper.getName());
print("Battery: " + flipper.getBatteryCharge().toString() + "%");

// -------------------------------------------------------------- notifier --
// If the screen flashes and the LED blinks, the notification service is up.
let notify = require("notification");
notify.success();
delay(300);

let colors = ["red", "green", "blue"];
for (let i = 0; i < colors.length; i++) {
    print("blink " + colors[i]);
    notify.blink(colors[i], "short");
    delay(400);
}

// --------------------------------------------------------------- storage --
// Round-trips a file on the SD card. Fails loudly if the card is absent,
// which is the most common reason a script "does nothing".
let storage = require("storage");
let path = "/ext/apps_data/js_smoke_test.txt";

print("");
print("Writing to " + path);

let file = storage.openFile(path, "w", "create_always");
if (file) {
    file.write("hello from the T-Embed");
    file.close();

    file = storage.openFile(path, "r", "open_existing");
    let text = file.read("ascii", 64);
    file.close();

    print("Read back: " + text);

    if (text === "hello from the T-Embed") {
        print("Storage round-trip OK");
    } else {
        print("Storage MISMATCH -- got: " + text);
    }

    storage.remove(path);
    print("Cleaned up");
} else {
    print("Could not open the file -- is an SD card inserted?");
}

// ------------------------------------------------------------------ maths --
// Confirms the math module and that numbers survive the engine intact.
let math = require("math");
print("");
print("sqrt(144)   = " + math.sqrt(144).toString());
print("PI          = " + math.PI.toString());

print("");
print("=== done ===");
notify.success();
