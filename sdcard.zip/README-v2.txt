T-Embed CC1101 / ESP32-S3 SD package for firmware 2.0.0
Extract the contents to the SD root. Do not format your existing card.
Keep your saved captures, credentials and settings if asked to replace them.
Use firmware with the deferred Sub-GHz app launch fix.
_preserved contains exact originals; do not extract those archives onto the card.
ARM native plugins are preserved there; NFC protocol support and JS modules
are built into this ESP32 firmware. Legacy native JS SD modules are retained.
NFC dictionaries combine both inputs. All source folders are retained.
This is a package repair, not a filesystem repair or a backup of your physical card.
Binary checks passed; app behavior still requires testing on the device.
