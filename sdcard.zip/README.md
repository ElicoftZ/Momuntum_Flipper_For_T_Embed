# SD card contents

Copy the contents of this folder to the root of a FAT32 SD card. Everything
here is optional — the firmware falls back to compiled-in assets when a path is
missing, which is why it boots fine with no card at all.

```
/dolphin/            desktop animations (36 sets) + manifest.txt
/asset_packs/        Momentum and WatchDogs packs (anims, icons, fonts)
/infrared/assets/    universal remote databases, incl. bluray_dvd, monitor,
                     digital_sign
/subghz/assets/      keeloq/nice/came manufacturer keys, example settings
/nfc/assets/         card dictionaries and parser databases (10 files)
/badusb/             40 demo scripts
/badusb/assets/layouts/   30 keyboard layouts
/lfrfid/assets/      RFID dictionary
/apps/ /subghz_remote/    empty, created for saved files
```

**`nfc/assets/sev_id.nfc`, `sk_id.nfc` and `sz_id.nfc` are required** by the
SEVPPK, SK and SZPPK card parsers. Without them those parsers cannot identify
a card, so copy them across if you use transit cards.

`mf_classic_dict.nfc` here is this port's own, which is larger than upstream's
(71 KB against 45 KB) — do not overwrite it with Momentum's.

## Notes

- `dolphin/manifest.txt` and each pack's `Anims/manifest.txt` are required for
  animations to load. Both are present.
- The Momentum pack has no `Fonts` directory upstream; WatchDogs has all three.
  Anything a pack omits falls back to the compiled-in asset.
- Select a pack under **Momentum > Interface > Graphics > Asset Pack**.
- `setting_user.example` and `keeloq_mfcodes_user.example` are templates. Rename
  them without `.example` to use them. The Frequencies editor
  (**Momentum > Protocols > Frequencies**) writes `setting_user` itself, so you
  do not need to create it by hand.
- Extended Range writes `subghz/assets/extend_range.txt` when enabled, and the
  custom device name is `dolphin/name.settings`. Both are created for you.
- Not included: `.fap` apps. Those are built separately and were not part of
  this port.
